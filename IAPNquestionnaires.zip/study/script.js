// Define study
const study = lab.util.fromObject({
  "title": "root",
  "type": "lab.flow.Sequence",
  "parameters": {},
  "plugins": [
    {
      "type": "lab.plugins.Metadata",
      "path": undefined
    }
  ],
  "metadata": {
    "title": "",
    "description": "",
    "repository": "",
    "contributors": ""
  },
  "messageHandlers": {
    "epilogue": function anonymous(
) {
var resultJson = study.options.datastore.exportJson();
jatos.submitResultData(resultJson, jatos.startNextComponent);
}
  },
  "files": {},
  "responses": {},
  "content": [
    {
      "type": "lab.html.Page",
      "items": [
        {
          "type": "text",
          "title": "Thank you for taking part in our study!",
          "content": "For this study you will first be asked to complete a series of questionnaires. For the first two you will be asked to provide basic information about yourself, and be asked about your current mental health. You do not have to disclose information about mental health if you do not wish.\nFor the second questionnaire you will be asked a series of questions about how you feel in your body. Please answers these as honestly as you can.\n\nAfter the questionnaires, you will then complete a line-judgement task. Here you will be asked to identify the midpoint of a series of different horizontal lines using your mouse or index finger (if you are using a touch screen).\n\nIn total, the experiment should last no longer than 30minutes."
        },
        {
          "required": true,
          "type": "text",
          "title": "Consent form",
          "content": "By ticking this box I consent to participate in this study. I understand that my participation is voluntary and I can withdraw from the study at any point in time, without providing a reason. "
        },
        {
          "required": true,
          "type": "checkbox",
          "options": [
            {
              "label": "Agree",
              "coding": "y"
            }
          ],
          "label": "I agree to participate in this study:",
          "name": "i-agree-to-participate-in-this-study:"
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "right",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "Consent"
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "type": "text",
          "title": "Demographics"
        },
        {
          "required": true,
          "type": "input",
          "label": "Age:",
          "attributes": {
            "type": "number"
          },
          "name": "age:"
        },
        {
          "required": true,
          "type": "input",
          "label": "Date of birth:",
          "attributes": {
            "type": "date"
          },
          "name": "date-of-birth:"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "Man",
              "coding": "M"
            },
            {
              "label": "Woman",
              "coding": "F"
            },
            {
              "label": "Non-binary",
              "coding": "NB"
            },
            {
              "label": "Rather not say",
              "coding": "non_disclosed"
            }
          ],
          "label": "Gender",
          "name": "gender"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "Right-handed",
              "coding": "right"
            },
            {
              "label": "Left-handed",
              "coding": "left"
            }
          ],
          "label": "I am predominantly",
          "name": "i-am-predominantly"
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "right",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "DemographicQ"
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "type": "text",
          "title": "Mental Health Questionnaire"
        },
        {
          "required": false,
          "type": "checkbox",
          "options": [
            {
              "label": "Panic disorder",
              "coding": "panic"
            },
            {
              "label": "Depression",
              "coding": "depression"
            },
            {
              "label": "Eating disorder",
              "coding": "eating"
            },
            {
              "label": "Somatic Symptom Disorder (e.g. chronic pain that affects daily life)",
              "coding": "somatic"
            },
            {
              "label": "Substance Use Disorder",
              "coding": "substance"
            },
            {
              "label": "Post-traumatic stress disorder",
              "coding": "ptsd"
            },
            {
              "label": "Generalised Anxiety Disorder",
              "coding": "anxiety"
            },
            {
              "label": "Depersonalisation Disorder",
              "coding": "depersonalisation"
            },
            {
              "label": "None",
              "coding": "none"
            },
            {
              "label": "Prefer not to say",
              "coding": "non_disclosed"
            },
            {
              "label": "Other",
              "coding": "other"
            }
          ],
          "label": "The following question is voluntary and disclosure is recommmended but not obligatory. Please mark the relevant checkbox if you consider yourself to be suffering from one of the following disorders during the past 3 months. You can select all that apply. ",
          "shuffle": true,
          "name": "the-following-question-is-voluntary-and-disclosure-is-recommmended-but-not-obligatory.-please-mark-the-relevant-checkbox-if-you-consider-yourself-to-be-suffering-from-one-of-the-following-disorders-during-the-past-3-months.-you-can-select-all-that-apply."
        },
        {
          "required": false,
          "type": "input",
          "label": "If 'other' please specify:",
          "name": "if-'other'-please-specify:"
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "right",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "MHQ"
    },
    {
      "type": "lab.html.Page",
      "items": [
        {
          "type": "text",
          "title": "Body States Questionnaire",
          "content": "Below you will find a list of statements. Please indicate how often each statement applies to you in daily life.\nThis questionnaire is adapted from the MAIA-2 by Mehling (2018)."
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "1. When I am tense I notice where the tension is located in my body",
          "name": "1.-when-i-am-tense-i-notice-where-the-tension-is-located-in-my-body"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "2. I notice when I am uncomfortable in my body",
          "name": "2.-i-notice-when-i-am-uncomfortable-in-my-body"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "3. I notice where in my body I am comfortable",
          "name": "3.-i-notice-where-in-my-body-i-am-comfortable"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "4. I notice changes in my breathing, such as whether it slows down or speeds up",
          "name": "4.-i-notice-changes-in-my-breathing-such-as-whether-it-slows-down-or-speeds-up"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "5. I ignore physical tension or discomfort until they become more severe",
          "name": "5.-i-ignore-physical-tension-or-discomfort-until-they-become-more-severe"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "6. I distract myself from sensations of discomfort",
          "name": "6.-i-distract-myself-from-sensations-of-discomfort"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "coding": "4",
              "label": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "7. When I feel pain or discomfort I try to power through it",
          "name": "7.-when-i-feel-pain-or-discomfort-i-try-to-power-through-it"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "8. I try to ignore pain",
          "name": "8.-i-try-to-ignore-pain"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "9. I push feelings of discomfort away by focusing on something",
          "name": "9.-i-push-feelings-of-discomfort-away-by-focusing-on-something"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "10. When I feel unpleasant body sensations, I occupy myself with something else so I do not have to feel them.",
          "name": "10.-when-i-feel-unpleasant-body-sensations-i-occupy-myself-with-something-else-so-i-do-not-have-to-feel-them."
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "11. When I feel physical pain, I become upset",
          "name": "11.-when-i-feel-physical-pain-i-become-upset"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "12. I start to worry that something is wrong if I feel any discomfort",
          "name": "12.-i-start-to-worry-that-something-is-wrong-if-i-feel-any-discomfort"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never ",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "13. I can notice an unpleasant body sensation without worrying about it",
          "name": "13.-i-can-notice-an-unpleasant-body-sensation-without-worrying-about-it"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "14. I can stay calm and not worry when I have feelings of discomfort or pain",
          "name": "14.-i-can-stay-calm-and-not-worry-when-i-have-feelings-of-discomfort-or-pain"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "15. When I am in discomfort or pain I can't get it out of my mind",
          "name": "15.-when-i-am-in-discomfort-or-pain-i-can't-get-it-out-of-my-mind"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "16. I can pay attention to my breath without being distracted by things happening around me",
          "name": "16.-i-can-pay-attention-to-my-breath-without-being-distracted-by-things-happening-around-me"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "17. I can maintain awareness of my inner bodily sensations even when there is a lot going on around me",
          "name": "17.-i-can-maintain-awareness-of-my-inner-bodily-sensations-even-when-there-is-a-lot-going-on-around-me"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "18. When I am in conversation with someone, I can pay attention to my posture",
          "name": "18.-when-i-am-in-conversation-with-someone-i-can-pay-attention-to-my-posture"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "19. I can return awareness to my body if I am distracted",
          "name": "19.-i-can-return-awareness-to-my-body-if-i-am-distracted"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "20. I can refocus my attention from thinking to sensing my body",
          "name": "20.-i-can-refocus-my-attention-from-thinking-to-sensing-my-body"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "21. I can maintain awareness of my body even when a part of me is in pain or discomfort",
          "name": "21.-i-can-maintain-awareness-of-my-body-even-when-a-part-of-me-is-in-pain-or-discomfort"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "22. I am able to consciously focus on my body as a whole",
          "name": "22.-i-am-able-to-consciously-focus-on-my-body-as-a-whole"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "coding": "2",
              "label": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "23. I notice how my body changes when I am angry",
          "name": "23.-i-notice-how-my-body-changes-when-i-am-angry"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "24. When something is wrong in daily life I can feel it in my body",
          "name": "24.-when-something-is-wrong-in-daily-life-i-can-feel-it-in-my-body"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "25. I notice that my body feels different after a peaceful experience",
          "name": "25.-i-notice-that-my-body-feels-different-after-a-peaceful-experience"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "26. I notice my breathing becomes free and easy when I am comfortable",
          "name": "26.-i-notice-my-breathing-becomes-free-and-easy-when-i-am-comfortable"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "27. I notice how my body changes when I feel happy\u002Fjoyful",
          "name": "27.-i-notice-how-my-body-changes-when-i-feel-happyjoyful"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "28. When I feel overwhelmed I can find a calm place inside",
          "name": "28.-when-i-feel-overwhelmed-i-can-find-a-calm-place-inside"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "29. When I bring awareness to my body I feel a sense of calm",
          "name": "29.-when-i-bring-awareness-to-my-body-i-feel-a-sense-of-calm"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "30. I can use my breath to reduce tension",
          "name": "30.-i-can-use-my-breath-to-reduce-tension"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "31. When I am caught up in thoughts, I can calm my mind by focusing on my body\u002Fbreathing",
          "name": "31.-when-i-am-caught-up-in-thoughts-i-can-calm-my-mind-by-focusing-on-my-bodybreathing"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "32. I listen for information from my body about my emotional state",
          "name": "32.-i-listen-for-information-from-my-body-about-my-emotional-state"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "33. When I am upset, I take time to explore how my body feels",
          "name": "33.-when-i-am-upset-i-take-time-to-explore-how-my-body-feels"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "34. I listen to my body to inform me about what to do",
          "name": "34.-i-listen-to-my-body-to-inform-me-about-what-to-do"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "35. I am at home in my body",
          "name": "35.-i-am-at-home-in-my-body"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "36. I feel my body is a safe place",
          "name": "36.-i-feel-my-body-is-a-safe-place"
        },
        {
          "required": true,
          "type": "radio",
          "options": [
            {
              "label": "0 - never",
              "coding": "0"
            },
            {
              "label": "1",
              "coding": "1"
            },
            {
              "label": "2",
              "coding": "2"
            },
            {
              "label": "3",
              "coding": "3"
            },
            {
              "label": "4",
              "coding": "4"
            },
            {
              "label": "5 - always",
              "coding": "5"
            }
          ],
          "label": "37. I trust my body sensations",
          "name": "37.-i-trust-my-body-sensations"
        }
      ],
      "scrollTop": true,
      "submitButtonText": "Continue →",
      "submitButtonPosition": "right",
      "files": {},
      "responses": {
        "": ""
      },
      "parameters": {},
      "messageHandlers": {},
      "title": "InteroceptionQ"
    }
  ]
})

// Let's go!
jatos.onLoad(() => study.run())